<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Category</h2>
  <a href="/create" class="btn btn-info">Create Category</a>
        
  <table class="table">
    <thead>
      <tr>
        <th>id</th>
        <th>category</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
    	 @foreach($category as $categorys)
      <tr>
        <td> {{$categorys->id }}</td>
        <td> {{$categorys->category }}</td>
        <td><a class="btn btn-info" href="edit/{{$categorys->id}}" name="Edit" >Edit</a>
          <!-- <a class="btn btn-danger" href="delete_category/{{$categorys->id}}" name="Edit" >Delete</a> -->

          <form method="POST" action="delete_category/{{$categorys->id}}">
            @csrf
            @method('delete')
            <input type="submit"  class="btn btn-danger" value="Delete">
          </form>
      </tr>

     @endforeach 
  
    </tbody>
  </table>
</div>

</body>
</html>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container">
  <h2>Edit Category</h2>
  <form method="POST" action="/update_category/<?php echo e($category->id); ?>">
    <?php echo csrf_field(); ?>
    <input type="text" name="category" value="<?php echo e($category->category); ?>">
    <input type="submit" name="" class="btn btn-info" value="Update">
  </form>
</div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel9\resources\views/category/edit.blade.php ENDPATH**/ ?>